#include "includeStatic/BadTimeGift.h"

void BadTimeGift::setType()
{
	m_giftType = GiftTypes::TimeDec;
}

