
#include "includeStatic/RemoveGnomeGift.h"

void RemoveGnomeGift::setType()
{
	m_giftType = GiftTypes::RemGnomes;
}

