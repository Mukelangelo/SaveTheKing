#include "includeStatic/StaticObject.h"

CollisionStatus StaticObject::getDispatch() const
{
	return m_dispatched;
}
