#include "includeStatic/StaticObject.h"

CollisionStatus StaticObject::getDispatch()
{
	return m_dispatched;
}
