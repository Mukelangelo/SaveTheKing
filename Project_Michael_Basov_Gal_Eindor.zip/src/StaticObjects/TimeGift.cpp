#include "includeStatic/TimeGift.h"

void TimeGift::setType()
{
	m_giftType = GiftTypes::TimeAdd;
}

