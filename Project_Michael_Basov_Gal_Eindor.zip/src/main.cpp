#include "Menu.h"

int main()
{
	auto menu = Menu();
	menu.run();
	return 0;
}